plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.personal.pokesurvivor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.personal.pokesurvivor"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-offline"
    }

    // Firma fija: asi cada APK nuevo se instala encima del anterior sin perder la partida.
    // (Solo para uso personal; no es una clave para publicar en Play Store.)
    signingConfigs {
        getByName("debug") {
            storeFile = file("pokesurvivor.keystore")
            storePassword = "pokesurvivor123"
            keyAlias = "pokesurvivor"
            keyPassword = "pokesurvivor123"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
