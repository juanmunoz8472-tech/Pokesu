# PokeSurvivor (APK personal, offline)

App Android que lleva el juego PokeSurvivor DENTRO del APK, asi que funciona sin internet.
Solo para uso personal. Pesa unos 110 MB porque incluye todos los sprites.

El juego es de JPTER78 (https://github.com/JPTER78/pokesurvivor): codigo con licencia MIT,
sprites con CC BY-NC 4.0 (uso no comercial, con atribucion; autores en CREDITS.md dentro del juego).
Pokemon y sus personajes son marcas de Nintendo, Creatures, GAME FREAK y The Pokemon Company.
Este APK no es oficial, no es comercial y no se debe publicar ni vender.

## Compilar en la nube desde el celular (GitHub Actions)

El juego NO va en este zip: el flujo de GitHub lo descarga del repositorio original
(version fija) y lo mete en la app al compilar.

1. En tu repositorio de GitHub, abre `.github/workflows/build.yml`, tocar el lapiz (Edit),
   seleccionar todo y pegar el contenido del `build.yml` nuevo. Commit changes.
2. Add file -> Upload files -> sube este `PokeSurvivor.zip` (reemplaza al anterior). Commit changes.
3. Pestana Actions: se ejecuta "Build APK" (tarda unos 5-10 minutos). Si no arranca solo:
   Build APK -> Run workflow.
4. Con el check verde, abre la ejecucion, baja a Artifacts y descarga `PokeSurvivor-apk`
   (zip con `app-debug.apk` dentro, ~110 MB).
5. Descomprime, abre el APK e instalalo.

IMPORTANTE la primera vez: desinstala la version anterior de la app (la que abria la web),
porque se firmo con otra clave. Desde esta version, la firma es fija y cada APK nuevo
se instala encima del anterior sin perder la partida.

## Como funciona

- Pantalla completa, horizontal. El juego se abre desde `file:///android_asset/game/index.html`.
- Modo local del juego: cuentas y partidas se guardan en el celular (localStorage de la app).
  No hay cuenta en la nube, ranking, ni amigos en linea. No es la misma partida que la de la web.
- Si desinstalas la app o borras sus datos, se pierde la partida.
- Los enlaces externos (creditos, etc.) se abren en el navegador.

## Actualizar el juego

En `build.yml`, la linea `ref:` fija la version del juego. Para tomar una version mas nueva,
cambia ese codigo por el de un commit mas reciente de https://github.com/JPTER78/pokesurvivor
y vuelve a ejecutar (Run workflow).

## Con Android Studio (PC)

1. Descarga el repo del juego y copia su contenido en `app/src/main/assets/game/`
   (sin `.git`, `docs`, `tools`, `functions`, `cloudflare`).
2. Abre esta carpeta en Android Studio -> Build -> Build APK(s).
